/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
GraphicEq2AudioProcessorEditor::GraphicEq2AudioProcessorEditor (GraphicEq2AudioProcessor& p)
    : AudioProcessorEditor (&p), processor (p)
{
    gain1SliderValue = std::make_unique<AudioProcessorValueTreeState::SliderAttachment>(processor.treeState, GAIN_ID, gain1Slider)
    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    setSize (400, 300);
    
}

GraphicEq2AudioProcessorEditor::~GraphicEq2AudioProcessorEditor()
{
}

//==============================================================================
void GraphicEq2AudioProcessorEditor::paint (Graphics& g)
{
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    g.fillAll (Colours::black);

}

void GraphicEq2AudioProcessorEditor::resized()
{
    // This is generally where you'll want to lay out the positions of any
    // subcomponents in your editor..
}

